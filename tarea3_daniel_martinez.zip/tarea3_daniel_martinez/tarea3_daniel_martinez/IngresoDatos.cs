﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tarea3_daniel_martinez
{
    public partial class IngresoDatos : Form
    {

        private string StrTipoId;
        private string StrNombre;
        private string StrNumId;
        private string StrEdad;
        private string StrAtencion;
        private string StrEstructura;
        private string StrEstrato;
        private string StrValorCopago;
        private string StrFecha;

        private int reportePila, reporteCola, reporteLista;


        Stack<EstructuraDatosUsuario> pilaUsuario = new Stack<EstructuraDatosUsuario>();
        Queue<EstructuraDatosUsuario> colaUsuario = new Queue<EstructuraDatosUsuario>();
        List<EstructuraDatosUsuario> listaUsuario = [];

        public IngresoDatos()
        {
            InitializeComponent();
            reportePila = 0;
            reporteCola = 0;
            reporteLista = 0;
            btnEliminarCola.Enabled = false;
            btnEliminarLista.Enabled = false;
            btnEliminarPila.Enabled = false;

            btnReporteCola.Enabled = false;
            btnReporteLista.Enabled = false;
            btnReportePila.Enabled = false;

        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {

            if (validarFormulario())
            {

                EstructuraDatosUsuario MiEstructura = new EstructuraDatosUsuario();
                MiEstructura.StrTipoId = StrTipoId;
                MiEstructura.StrNumId = StrNumId;
                MiEstructura.StrNombre = StrNombre;
                MiEstructura.StrEstrato = StrEstrato;
                MiEstructura.StrEdad = StrEdad;
                MiEstructura.Fecha = StrFecha;
                MiEstructura.StrAtencion = StrAtencion;
                MiEstructura.StrValorCopago = StrValorCopago;


                if (StrEstructura.Equals("Pila"))
                {
                    reportePila = reportePila + int.Parse(StrValorCopago);
                    pilaUsuario.Push(MiEstructura);
                    dataGridPila.DataSource = null;
                    dataGridPila.DataSource = pilaUsuario.ToArray();
                    tabControl1.SelectedTab = tabPila;
                    MessageBox.Show("El registro fue correcto en la pila");
                    btnEliminarPila.Enabled = true;
                    btnReportePila.Enabled = true;
                    Limpiar();
                }
                if (StrEstructura.Equals("Cola"))
                {

                    reporteCola = reporteCola + 1;
                    colaUsuario.Enqueue(MiEstructura);
                    dataGridCola.DataSource = null;
                    dataGridCola.DataSource = colaUsuario.ToArray();
                    tabControl1.SelectedTab = tabCola;
                    MessageBox.Show("El registro fue correcto en la cola");
                    btnEliminarCola.Enabled = true;
                    btnReporteCola.Enabled = true;
                    Limpiar();


                }

                if (StrEstructura.Equals("Lista"))
                {
                    reporteLista = reporteLista + int.Parse(StrEdad);
                    listaUsuario.Add(MiEstructura);
                    dataGridLista.DataSource = null;
                    dataGridLista.DataSource = listaUsuario.ToArray();
                    tabControl1.SelectedTab = tabLista;
                    MessageBox.Show("El registro fue correcto en la lista");
                    btnEliminarLista.Enabled = true;
                    btnReporteLista.Enabled = true;


                    Limpiar();

                }

            }





        }


        private bool validarFormulario()
        {
            string strmessage = string.Empty;
            StrTipoId = cmbTipoId.Text.Trim();

            if (StrTipoId.Equals("")) strmessage = strmessage + "-tipo de identificacion \n";

            StrNumId = txtNumId.Text.Trim();

            if (StrNumId.Equals("")) strmessage = strmessage + "- número de identificacion \n";

            StrNombre = txtNombre.Text.Trim();

            if (StrNombre.Equals("")) strmessage = strmessage + "- Nombre \n";

            StrEdad = txtEdad.Text.Trim();

            if (StrEdad.Equals("")) strmessage = strmessage + "- Edad \n";

            StrFecha = FechaIngreso.Text.Trim();

            if (StrFecha.Equals("")) strmessage = strmessage + "- Fecha Ingreso \n";

            StrEstrato = cmbEstrato.Text.Trim();

            if (StrEstrato.Equals("")) strmessage = strmessage + "- Estrato \n";

            if (btnMedicina.Checked.Equals(false) && btnExamen.Checked.Equals(false))
            {
                strmessage = strmessage + "- tipo de atención \n";
            }
            else if (btnMedicina.Checked.Equals(true))
            {
                StrAtencion = "Medicina General";
            }
            else
            {
                StrAtencion = "Examen de laboratorio";

            }

            StrEstructura = cmbEstructura.Text.Trim();
            if (StrEstructura.Equals("")) strmessage = strmessage + "- Estructura \n";

            if (!strmessage.Equals(""))
            {

                strmessage = "Debe diligenciar los  siguientes campos n" + strmessage;
                MessageBox.Show(strmessage);
                return false;

            }
            else
            {
                StrValorCopago = CalcularValorCopago().ToString();
                txtCopago.Text = StrValorCopago;
                return true;

            }

        }

        private int CalcularValorCopago()
        {

            int valorCopago = 0;

            if (StrAtencion.Equals("Medicina General"))
            {
                switch (StrEstrato)
                {

                    case "1":
                        valorCopago = 0;

                        break;
                    case "2":
                        valorCopago = 0;
                        break;
                    case "3":
                        valorCopago = 10000;
                        break;
                    case "4":
                        valorCopago = 15000;
                        break;
                    case "5":
                        valorCopago = 20000;
                        break;
                    case "6":
                        valorCopago = 30000;
                        break;

                }

            }
            else
            {

                switch (StrEstrato)
                {
                    case "1":
                        valorCopago = 0;

                        break;
                    case "2":
                        valorCopago = 0;
                        break;
                    case "3":
                        valorCopago = 0;
                        break;
                    case "4":
                        valorCopago = 5000;
                        break;
                    case "5":
                        valorCopago = 10000;
                        break;
                    case "6":
                        valorCopago = 20000;
                        break;
                }
            }

            return valorCopago;

        }

        private void Limpiar()
        {
            cmbTipoId.Text = "";
            txtNumId.Text = "";
            txtNombre.Text = "";
            txtEdad.Text = "";
            cmbEstrato.Text = "";
            btnMedicina.Checked = false;
            btnExamen.Checked = false;
            txtReporte.Text = string.Empty;
            cmbEstructura.Text = string.Empty;
            txtCopago.Text = string.Empty;
            FechaIngreso.Value = DateTime.Now;
            cmbTipoId.Focus();


        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        
        private void btnReportePila_Click(object sender, EventArgs e)
        {
            txtReporte.Text = reportePila.ToString();
        }

        private void btnEliminarPila_Click(object sender, EventArgs e)
        {
            if (pilaUsuario.Count > 0)
            {
                EstructuraDatosUsuario MiEstructura = new EstructuraDatosUsuario();
                MiEstructura = pilaUsuario.Pop();
                reportePila = reportePila - int.Parse(MiEstructura.StrValorCopago);
                txtReporte.Text = reportePila.ToString();
                dataGridPila.DataSource = pilaUsuario.ToArray();
                MessageBox.Show("El último registro se ha borrado");

            }
            else
            {
                MessageBox.Show("No hay registros");
                btnEliminarPila.Enabled = false;
                btnReportePila.Enabled = false;
            }
        }

        private void btnReporteCola_Click(object sender, EventArgs e)
        {
            txtReporte.Text = reporteCola.ToString();
        }

        private void btnEliminarCola_Click(object sender, EventArgs e)
        {
            if (colaUsuario.Count > 0)
            {
                EstructuraDatosUsuario MiEstructura = new EstructuraDatosUsuario();
                MiEstructura = colaUsuario.Dequeue();
                reporteCola = reporteCola - 1;
                txtReporte.Text = reporteCola.ToString();
                dataGridCola.DataSource = colaUsuario.ToArray();
                MessageBox.Show("El último registro se ha borrado");

            }
            else
            {
                MessageBox.Show("No hay registros");
                btnEliminarCola.Enabled = false;
                btnReporteCola.Enabled = false;
            }
        }

        private void btnReporteLista_Click(object sender, EventArgs e)
        {

            txtReporte.Text = reporteLista.ToString();
        }

        private void btnEliminarLista_Click(object sender, EventArgs e)
        {
            if (listaUsuario.Count > 0)
            {
                EstructuraDatosUsuario MiEstructura = new EstructuraDatosUsuario();

                MiEstructura = listaUsuario.Last();

                reporteLista = reporteLista - int.Parse(MiEstructura.StrEdad);
                txtReporte.Text = reporteLista.ToString();
                dataGridLista.DataSource = listaUsuario.ToArray();
                MessageBox.Show("El último registro se ha borrado");

            }
            else
            {
                MessageBox.Show("No hay registros");
                btnEliminarLista.Enabled = false;
                btnReporteLista.Enabled = false;
            }
        }

        private void btnSalir_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}



