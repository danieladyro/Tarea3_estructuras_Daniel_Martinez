﻿namespace tarea3_daniel_martinez
{
    partial class IngresoDatos
    {
        
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            lbl_tipoid = new Label();
            cmbTipoId = new ComboBox();
            label2 = new Label();
            lbl_nombre = new Label();
            txtNombre = new TextBox();
            txtNumId = new TextBox();
            txtEdad = new TextBox();
            label3 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            groupBox1 = new GroupBox();
            btnMedicina = new RadioButton();
            btnExamen = new RadioButton();
            FechaIngreso = new DateTimePicker();
            label8 = new Label();
            cmbEstrato = new ComboBox();
            cmbEstructura = new ComboBox();
            label9 = new Label();
            btnRegistrar = new Button();
            btnLimpiar = new Button();
            btnSalir = new Button();
            tabControl1 = new TabControl();
            tabPila = new TabPage();
            btnEliminarPila = new Button();
            btnReportePila = new Button();
            dataGridPila = new DataGridView();
            tabCola = new TabPage();
            btnEliminarCola = new Button();
            btnReporteCola = new Button();
            dataGridCola = new DataGridView();
            tabLista = new TabPage();
            btnEliminarLista = new Button();
            btnReporteLista = new Button();
            dataGridLista = new DataGridView();
            txtCopago = new TextBox();
            txtReporte = new TextBox();
            groupBox1.SuspendLayout();
            tabControl1.SuspendLayout();
            tabPila.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridPila).BeginInit();
            tabCola.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridCola).BeginInit();
            tabLista.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridLista).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(158, 18);
            label1.Name = "label1";
            label1.Size = new Size(202, 15);
            label1.TabIndex = 0;
            label1.Text = "SISTEMA DE REGISTRO DE USUARIOS";
            // 
            // lbl_tipoid
            // 
            lbl_tipoid.AutoSize = true;
            lbl_tipoid.Location = new Point(21, 44);
            lbl_tipoid.Name = "lbl_tipoid";
            lbl_tipoid.Size = new Size(122, 15);
            lbl_tipoid.TabIndex = 1;
            lbl_tipoid.Text = "Tipo de identificación";
            // 
            // cmbTipoId
            // 
            cmbTipoId.AutoCompleteCustomSource.AddRange(new string[] { "CC", "TI", "RC", "PEP" });
            cmbTipoId.FormattingEnabled = true;
            cmbTipoId.Items.AddRange(new object[] { "CC", "TI", "RC", "PEP" });
            cmbTipoId.Location = new Point(187, 44);
            cmbTipoId.Name = "cmbTipoId";
            cmbTipoId.Size = new Size(121, 23);
            cmbTipoId.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(21, 101);
            label2.Name = "label2";
            label2.Size = new Size(134, 15);
            label2.TabIndex = 3;
            label2.Text = "Estrato socioeconómico";
            // 
            // lbl_nombre
            // 
            lbl_nombre.AutoSize = true;
            lbl_nombre.Location = new Point(21, 75);
            lbl_nombre.Name = "lbl_nombre";
            lbl_nombre.Size = new Size(105, 15);
            lbl_nombre.TabIndex = 1;
            lbl_nombre.Text = "Nombre completo";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(187, 72);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(216, 23);
            txtNombre.TabIndex = 4;
            // 
            // txtNumId
            // 
            txtNumId.Location = new Point(616, 44);
            txtNumId.Name = "txtNumId";
            txtNumId.Size = new Size(133, 23);
            txtNumId.TabIndex = 7;
            // 
            // txtEdad
            // 
            txtEdad.Location = new Point(618, 70);
            txtEdad.Name = "txtEdad";
            txtEdad.Size = new Size(100, 23);
            txtEdad.TabIndex = 8;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(21, 127);
            label3.Name = "label3";
            label3.Size = new Size(95, 15);
            label3.TabIndex = 10;
            label3.Text = "Valor del copago";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(22, 152);
            label5.Name = "label5";
            label5.Size = new Size(103, 15);
            label5.TabIndex = 12;
            label5.Text = "Tipo de estructura";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(461, 46);
            label6.Name = "label6";
            label6.Size = new Size(142, 15);
            label6.TabIndex = 13;
            label6.Text = "Número de identificación";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(461, 72);
            label7.Name = "label7";
            label7.Size = new Size(33, 15);
            label7.TabIndex = 14;
            label7.Text = "Edad";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnMedicina);
            groupBox1.Controls.Add(btnExamen);
            groupBox1.Location = new Point(470, 94);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(318, 60);
            groupBox1.TabIndex = 15;
            groupBox1.TabStop = false;
            groupBox1.Text = "Tipo de atención";
            // 
            // btnMedicina
            // 
            btnMedicina.AutoSize = true;
            btnMedicina.Location = new Point(183, 29);
            btnMedicina.Name = "btnMedicina";
            btnMedicina.Size = new Size(116, 19);
            btnMedicina.TabIndex = 1;
            btnMedicina.TabStop = true;
            btnMedicina.Text = "Medicina general";
            btnMedicina.UseVisualStyleBackColor = true;
            // 
            // btnExamen
            // 
            btnExamen.AutoSize = true;
            btnExamen.Location = new Point(19, 28);
            btnExamen.Name = "btnExamen";
            btnExamen.Size = new Size(143, 19);
            btnExamen.TabIndex = 0;
            btnExamen.TabStop = true;
            btnExamen.Text = "Examen de laboratorio";
            btnExamen.UseVisualStyleBackColor = true;
            // 
            // FechaIngreso
            // 
            FechaIngreso.Format = DateTimePickerFormat.Short;
            FechaIngreso.Location = new Point(589, 159);
            FechaIngreso.MaxDate = new DateTime(2050, 12, 31, 0, 0, 0, 0);
            FechaIngreso.MinDate = new DateTime(2024, 1, 1, 0, 0, 0, 0);
            FechaIngreso.Name = "FechaIngreso";
            FechaIngreso.Size = new Size(200, 23);
            FechaIngreso.TabIndex = 16;
            FechaIngreso.Value = new DateTime(2025, 7, 25, 23, 59, 59, 0);
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(458, 163);
            label8.Name = "label8";
            label8.Size = new Size(93, 15);
            label8.TabIndex = 17;
            label8.Text = "Fecha de acceso";
            // 
            // cmbEstrato
            // 
            cmbEstrato.FormattingEnabled = true;
            cmbEstrato.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6" });
            cmbEstrato.Location = new Point(187, 98);
            cmbEstrato.Name = "cmbEstrato";
            cmbEstrato.Size = new Size(121, 23);
            cmbEstrato.TabIndex = 18;
            // 
            // cmbEstructura
            // 
            cmbEstructura.FormattingEnabled = true;
            cmbEstructura.Items.AddRange(new object[] { "Pila", "Cola", "Lista" });
            cmbEstructura.Location = new Point(188, 148);
            cmbEstructura.Name = "cmbEstructura";
            cmbEstructura.Size = new Size(121, 23);
            cmbEstructura.TabIndex = 19;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(23, 184);
            label9.Name = "label9";
            label9.Size = new Size(96, 15);
            label9.TabIndex = 20;
            label9.Text = "Reporte de datos";
            // 
            // btnRegistrar
            // 
            btnRegistrar.Location = new Point(410, 218);
            btnRegistrar.Name = "btnRegistrar";
            btnRegistrar.Size = new Size(75, 22);
            btnRegistrar.TabIndex = 22;
            btnRegistrar.Text = "Registrar";
            btnRegistrar.UseVisualStyleBackColor = true;
            btnRegistrar.Click += btnRegistrar_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Location = new Point(559, 218);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(75, 22);
            btnLimpiar.TabIndex = 23;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // btnSalir
            // 
            btnSalir.Location = new Point(688, 218);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(75, 22);
            btnSalir.TabIndex = 24;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click_1;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPila);
            tabControl1.Controls.Add(tabCola);
            tabControl1.Controls.Add(tabLista);
            tabControl1.Location = new Point(22, 260);
            tabControl1.Margin = new Padding(2);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(764, 106);
            tabControl1.TabIndex = 25;
            // 
            // tabPila
            // 
            tabPila.Controls.Add(btnEliminarPila);
            tabPila.Controls.Add(btnReportePila);
            tabPila.Controls.Add(dataGridPila);
            tabPila.Location = new Point(4, 24);
            tabPila.Margin = new Padding(2);
            tabPila.Name = "tabPila";
            tabPila.Padding = new Padding(2);
            tabPila.Size = new Size(756, 78);
            tabPila.TabIndex = 0;
            tabPila.Text = "Pila";
            tabPila.UseVisualStyleBackColor = true;
            // 
            // btnEliminarPila
            // 
            btnEliminarPila.Location = new Point(612, 47);
            btnEliminarPila.Margin = new Padding(3, 2, 3, 2);
            btnEliminarPila.Name = "btnEliminarPila";
            btnEliminarPila.Size = new Size(100, 20);
            btnEliminarPila.TabIndex = 2;
            btnEliminarPila.Text = "Eliminar";
            btnEliminarPila.UseVisualStyleBackColor = true;
            btnEliminarPila.Click += btnEliminarPila_Click;
            // 
            // btnReportePila
            // 
            btnReportePila.Location = new Point(612, 15);
            btnReportePila.Margin = new Padding(3, 2, 3, 2);
            btnReportePila.Name = "btnReportePila";
            btnReportePila.Size = new Size(100, 20);
            btnReportePila.TabIndex = 1;
            btnReportePila.Text = "Reporte";
            btnReportePila.UseVisualStyleBackColor = true;
            btnReportePila.Click += btnReportePila_Click;
            // 
            // dataGridPila
            // 
            dataGridPila.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridPila.Location = new Point(2, 4);
            dataGridPila.Margin = new Padding(2);
            dataGridPila.Name = "dataGridPila";
            dataGridPila.RowHeadersWidth = 62;
            dataGridPila.Size = new Size(584, 76);
            dataGridPila.TabIndex = 0;
            // 
            // tabCola
            // 
            tabCola.Controls.Add(btnEliminarCola);
            tabCola.Controls.Add(btnReporteCola);
            tabCola.Controls.Add(dataGridCola);
            tabCola.Location = new Point(4, 24);
            tabCola.Margin = new Padding(2);
            tabCola.Name = "tabCola";
            tabCola.Padding = new Padding(2);
            tabCola.Size = new Size(756, 78);
            tabCola.TabIndex = 1;
            tabCola.Text = "Cola";
            tabCola.UseVisualStyleBackColor = true;
            // 
            // btnEliminarCola
            // 
            btnEliminarCola.Location = new Point(645, 51);
            btnEliminarCola.Margin = new Padding(3, 2, 3, 2);
            btnEliminarCola.Name = "btnEliminarCola";
            btnEliminarCola.Size = new Size(82, 20);
            btnEliminarCola.TabIndex = 2;
            btnEliminarCola.Text = "Eliminar";
            btnEliminarCola.UseVisualStyleBackColor = true;
            btnEliminarCola.Click += btnEliminarCola_Click;
            // 
            // btnReporteCola
            // 
            btnReporteCola.Location = new Point(645, 16);
            btnReporteCola.Margin = new Padding(3, 2, 3, 2);
            btnReporteCola.Name = "btnReporteCola";
            btnReporteCola.Size = new Size(82, 20);
            btnReporteCola.TabIndex = 1;
            btnReporteCola.Text = "Reporte";
            btnReporteCola.UseVisualStyleBackColor = true;
            btnReporteCola.Click += btnReporteCola_Click;
            // 
            // dataGridCola
            // 
            dataGridCola.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridCola.Location = new Point(2, 2);
            dataGridCola.Margin = new Padding(2);
            dataGridCola.Name = "dataGridCola";
            dataGridCola.RowHeadersWidth = 62;
            dataGridCola.Size = new Size(607, 78);
            dataGridCola.TabIndex = 0;
            // 
            // tabLista
            // 
            tabLista.Controls.Add(btnEliminarLista);
            tabLista.Controls.Add(btnReporteLista);
            tabLista.Controls.Add(dataGridLista);
            tabLista.Location = new Point(4, 24);
            tabLista.Margin = new Padding(2);
            tabLista.Name = "tabLista";
            tabLista.Size = new Size(756, 78);
            tabLista.TabIndex = 2;
            tabLista.Text = "Lista";
            tabLista.UseVisualStyleBackColor = true;
            // 
            // btnEliminarLista
            // 
            btnEliminarLista.Location = new Point(632, 46);
            btnEliminarLista.Margin = new Padding(3, 2, 3, 2);
            btnEliminarLista.Name = "btnEliminarLista";
            btnEliminarLista.Size = new Size(83, 20);
            btnEliminarLista.TabIndex = 2;
            btnEliminarLista.Text = "Eliminar";
            btnEliminarLista.UseVisualStyleBackColor = true;
            btnEliminarLista.Click += btnEliminarLista_Click;
            // 
            // btnReporteLista
            // 
            btnReporteLista.Location = new Point(632, 13);
            btnReporteLista.Margin = new Padding(3, 2, 3, 2);
            btnReporteLista.Name = "btnReporteLista";
            btnReporteLista.Size = new Size(83, 20);
            btnReporteLista.TabIndex = 1;
            btnReporteLista.Text = "Reporte";
            btnReporteLista.UseVisualStyleBackColor = true;
            btnReporteLista.Click += btnReporteLista_Click;
            // 
            // dataGridLista
            // 
            dataGridLista.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridLista.Location = new Point(2, 2);
            dataGridLista.Margin = new Padding(2);
            dataGridLista.Name = "dataGridLista";
            dataGridLista.RowHeadersWidth = 62;
            dataGridLista.Size = new Size(593, 80);
            dataGridLista.TabIndex = 0;
            // 
            // txtCopago
            // 
            txtCopago.Enabled = false;
            txtCopago.Location = new Point(187, 123);
            txtCopago.Margin = new Padding(2);
            txtCopago.Name = "txtCopago";
            txtCopago.Size = new Size(133, 23);
            txtCopago.TabIndex = 26;
            // 
            // txtReporte
            // 
            txtReporte.Enabled = false;
            txtReporte.Location = new Point(188, 181);
            txtReporte.Margin = new Padding(2);
            txtReporte.Name = "txtReporte";
            txtReporte.Size = new Size(133, 23);
            txtReporte.TabIndex = 27;
            // 
            // IngresoDatos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(860, 380);
            Controls.Add(txtReporte);
            Controls.Add(txtCopago);
            Controls.Add(tabControl1);
            Controls.Add(btnSalir);
            Controls.Add(btnLimpiar);
            Controls.Add(btnRegistrar);
            Controls.Add(label9);
            Controls.Add(cmbEstructura);
            Controls.Add(cmbEstrato);
            Controls.Add(label8);
            Controls.Add(FechaIngreso);
            Controls.Add(groupBox1);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(txtEdad);
            Controls.Add(txtNumId);
            Controls.Add(txtNombre);
            Controls.Add(label2);
            Controls.Add(cmbTipoId);
            Controls.Add(lbl_tipoid);
            Controls.Add(lbl_nombre);
            Controls.Add(label1);
            Name = "IngresoDatos";
            Text = "IngresoDatos";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            tabControl1.ResumeLayout(false);
            tabPila.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridPila).EndInit();
            tabCola.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridCola).EndInit();
            tabLista.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridLista).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label lbl_tipoid;
        private ComboBox cmbTipoId;
        private Label label2;
        private Label lbl_nombre;
        private TextBox txtNombre;
        private TextBox txtNumId;
        private TextBox txtEdad;
        private Label label3;
        private Label label5;
        private Label label6;
        private Label label7;
        private GroupBox groupBox1;
        private RadioButton btnMedicina;
        private RadioButton btnExamen;
        private DateTimePicker FechaIngreso;
        private Label label8;
        private ComboBox cmbEstrato;
        private ComboBox cmbEstructura;
        private Label label9;
        private Button btnRegistrar;
        private Button btnLimpiar;
        private Button btnSalir;
        private TabControl tabControl1;
        private TabPage tabPila;
        private TabPage tabCola;
        private TabPage tabLista;
        private DataGridView dataGridPila;
        private DataGridView dataGridCola;
        private DataGridView dataGridLista;
        private TextBox txtCopago;
        private TextBox txtReporte;
        private Button btnEliminarPila;
        private Button btnReportePila;
        private Button btnEliminarCola;
        private Button btnReporteCola;
        private Button btnEliminarLista;
        private Button btnReporteLista;
    }
}