using System.Windows.Forms.VisualStyles;

namespace tarea3_daniel_martinez
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void btn_ingresar_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "")
            {
                MessageBox.Show("Digite la clave");
            }
            else
            {
                if (textBox1.Text == "123")
                {
                    MessageBox.Show("Contrase�a correcta");

                    IngresoDatos Midatos = new IngresoDatos();
                    Midatos.Show();
                    this.Hide();


                }
                else
                {
                    MessageBox.Show("Contrase�a invalida");
                    textBox1.Clear();
                    textBox1.Focus();
                }
            }

        }

                
        private void btn_salir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
