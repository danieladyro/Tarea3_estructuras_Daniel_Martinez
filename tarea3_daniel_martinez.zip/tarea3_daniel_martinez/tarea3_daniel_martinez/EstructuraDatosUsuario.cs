﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tarea3_daniel_martinez
{
    internal class EstructuraDatosUsuario
    {

        public  string ? StrTipoId { get; set; }
        public  string ? StrNumId { get; set; }
        public  string ? StrEdad { get; set; } = string.Empty;

        public   string ? StrNombre { get; set; }

        public  string ? StrAtencion { get; set; }

        public  string ? StrEstrato { get; set; }

        public  string ? Fecha { get; set; }

        public  string ? StrValorCopago { get; set; }


    }
}
